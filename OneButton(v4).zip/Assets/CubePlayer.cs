﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class CubePlayer : MonoBehaviour
{
    // Start is called before the first frame update
    Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        
        if(rb.velocity.magnitude < 25){
            rb.AddForce(Input.GetAxis("Horizontal") * 25, 0, Input.GetAxis("Vertical") * 25);
        }
    }

    void OnTriggerEnter(Collider other) {
        Debug.Log("------***Ending hit**---------  " + other.gameObject.name);
        if(other.gameObject.CompareTag("Target"))
        {
            Time.timeScale = 0;
        }
    }

}
