﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SecurityCam : MonoBehaviour
{
    // Start is called before the first frame update


    [SerializeField] 
    Rigidbody bullet;

    [SerializeField]
    Transform FirePoint;

    

    bool gunIsFiring = true;
    public Transform rayEmitter;
    private RaycastHit hit;
    private Renderer rend;
    void Start()
    {
        rend = GetComponent<Renderer>();
    }

    // Update is called once per frame
    void Update()
    {
        if(Physics.Raycast(rayEmitter.position, transform.forward, out hit)) {
            if(hit.collider.CompareTag("Player")){
                rend.material.color = Color.white;
                if(gunIsFiring){
            //gunIsFiring.enabled = =!gunIsFiring.enabled;
                    bullet = Instantiate(bullet, FirePoint.position, FirePoint.rotation, null);
                    bullet.GetComponent<Rigidbody>().AddForce(transform.forward * 500);
                    gunIsFiring = false;
                    StartCoroutine(Wait());        
                }

            } else {
                rend.material.color = Color.green;
            }

            Debug.Log("I have hit!" + hit.collider.name);
        }

        Debug.DrawRay(rayEmitter.position, transform.forward * 10, Color.white, 1);
    }
    
    IEnumerator Wait(){
        yield return new WaitForSeconds(3);
        gunIsFiring = true;
    }
}
