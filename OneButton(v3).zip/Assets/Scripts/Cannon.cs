﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Cannon : MonoBehaviour
{
    [SerializeField] 
    Transform FirePoint;
    [SerializeField] Rigidbody bulletPrefab;

    public bool gunIsFiring = true;
    public float bulletCharge = 10f;
    public float bulletPower;
    public int bulletAmount = 0;
   

    void Update(){
        if(Input.GetButton("Fire1")){
            Debug.Log("You are charging up your shot");
            bulletPower += Time.deltaTime * 50;
    
        }

        if(Input.GetButtonUp("Fire1")){
            Debug.Log("You have released the shot!");
            Fire();
            bulletCharge = 10f;
            bulletPower = 0f;
            bulletAmount += 1; 
        }

        if(bulletAmount > 3){
            Debug.Log("Shots passed 3!");
            UnityEditor.EditorApplication.isPlaying = false;
        }
    }

    void Fire(){
        if(gunIsFiring){
            Rigidbody bullet = Instantiate(bulletPrefab, FirePoint.position, FirePoint.rotation, null);
            bullet.GetComponent<Rigidbody>().AddRelativeForce(transform.forward * bulletPower, ForceMode.Impulse);
            gunIsFiring = false;
            StartCoroutine(Wait());        
        }
    }

    IEnumerator Wait(){
        yield return new WaitForSeconds(1);
        gunIsFiring = true;
    }
}
