﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerComponent : MonoBehaviour
{
    public int targetHit = 0;
    // Start is called before the first frame update
    public int currScore;

    [SerializeField] Text scoreAmount;

    void Start()
    {
        currScore = targetHit;
        UpdateScoreUI();
    }

   
    void OnTriggerEnter(Collider other) {
        Debug.Log("I have hit " + other.gameObject.name);
        if(other.gameObject.CompareTag("Targets"))
        {
            //destroy the coin
            //Destroy(other.gameObject);
            Debug.Log("I'm adding points!");
            targetHit += 100;
            currScore += 100;
            UpdateScoreUI();
        }
    }

    private void UpdateScoreUI()
    {
        
        scoreAmount.text = "Score: " + currScore.ToString("0");
        Debug.Log("Trying to update!!");

    }
}
